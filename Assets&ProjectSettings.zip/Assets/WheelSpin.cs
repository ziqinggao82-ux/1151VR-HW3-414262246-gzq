using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WheelSpin : MonoBehaviour
{
    public GameObject slicePrefab;
    public TMP_InputField optionInput;
    public Button addButton;
    public Button spinButton;
    public TMP_Text resultText; 
    public AudioSource audioSource;
    public AudioClip clickClip; // 點擊聲
    public AudioClip spinClip;  // 轉動聲
    public AudioClip winClip;   // 中獎聲

    List<string> options = new List<string> {"A","B","C","D"};

    Color[] colors = {
        new Color(1f, 0.4f, 0.4f), new Color(1f, 0.7f, 0.3f),
        new Color(1f, 0.9f, 0.3f), new Color(0.5f, 0.85f, 0.4f),
        new Color(0.3f, 0.7f, 0.9f), new Color(0.6f, 0.5f, 0.9f)
    };

    bool spinning;

    void Play(AudioClip clip)
    {
    if (clip != null && audioSource != null)
        audioSource.PlayOneShot(clip);
    }

    void Start()
    {
        addButton.onClick.AddListener(AddOption);
        spinButton.onClick.AddListener(Spin);
        Rebuild();
    }

        void AddOption()
        {
        string text = optionInput.text.Trim();
        if (string.IsNullOrEmpty(text) || spinning) return;
        if (options.Count >= 12) return; // 上限 12 個
        options.Add(text);
        Play(clickClip);
        optionInput.text = "";
        if (resultText != null) resultText.text = "";
        Rebuild();
        }

    void RemoveOption(int index)
    {
        if (spinning) return;
        if (index < 0 || index >= options.Count) return;
        options.RemoveAt(index);
        Play(clickClip);
        if (resultText != null) resultText.text = "";
        Rebuild();
    }

    void Rebuild()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            Transform c = transform.GetChild(i);
            c.gameObject.SetActive(false);
            Destroy(c.gameObject);
        }

        int n = options.Count;
        if (n == 0)
        {
            if (resultText != null) resultText.text = "請先新增選項";
            return;
        }
        float sliceAngle = 360f / n;

        for (int i = 0; i < n; i++)
        {
            GameObject slice = Instantiate(slicePrefab, transform);
            slice.name = "Slice" + i;

            Image img = slice.GetComponent<Image>();
            img.fillAmount = 1f / n;
            img.color = Color.HSVToRGB((float)i / n, 0.55f, 0.95f);

            slice.transform.localRotation = Quaternion.Euler(0, 0, -sliceAngle * i);

            // 文字放在扇形中間：旋轉半個扇形角度
            TMP_Text label = slice.GetComponentInChildren<TMP_Text>();
            label.text = options[i];
            int captured = i; // 必須先存起來，不然所有按鈕都會刪到最後一項
            label.raycastTarget = true;
            Button btn = label.gameObject.GetComponent<Button>();
            if (btn == null) btn = label.gameObject.AddComponent<Button>();
            btn.onClick.RemoveAllListeners();
            btn.onClick.AddListener(() => RemoveOption(captured));
            label.transform.localRotation = Quaternion.identity;
            float mid = -sliceAngle / 2f * Mathf.Deg2Rad;
            float r = 280f;
            label.rectTransform.anchoredPosition =
                new Vector2(-Mathf.Sin(mid) * r, Mathf.Cos(mid) * r);
        }
    }

    public void Spin()
    {
        if (spinning || options.Count == 0) return;
        StartCoroutine(SpinRoutine());
    }

    IEnumerator SpinRoutine()
    {
        spinning = true;
        Play(clickClip);
        audioSource.clip = spinClip;
        audioSource.loop = true;
        audioSource.Play();
        if (resultText != null) resultText.text = "";
        float duration = Random.Range(3f, 5f);
        float totalAngle = Random.Range(1440f, 2160f);
        float startZ = transform.eulerAngles.z;
        float t = 0;

        while (t < duration)
        {
            t += Time.deltaTime;
            float p = 1 - Mathf.Pow(1 - t / duration, 3);
            transform.eulerAngles = new Vector3(0, 0, startZ - totalAngle * p);
            yield return null;
        }

        float finalZ = (transform.eulerAngles.z % 360 + 360) % 360;
        float sliceAngle = 360f / options.Count;
        int index = Mathf.FloorToInt(finalZ / sliceAngle) % options.Count;
        audioSource.Stop();
        audioSource.loop = false;
        Play(winClip);
        if (resultText != null) resultText.text = "結果：" + options[index];
        Debug.Log("結果：" + options[index]);
        spinning = false;
    }
}